# GSLsys.com - Granada SportLine

Aplicación web corporativa para Granada SportLine: inventario de accesorios deportivos y equipo de streaming, finanzas, recursos humanos y administración de usuarios, con reportes PDF.

- **Backend:** Python, FastAPI, SQLAlchemy y SQLite (el archivo `backend/gslsys.db` se crea solo).
- **Frontend:** React con Vite, React Router DOM y Tailwind CSS.
- **PDFs:** ReportLab, con membrete en azul marino y rojo corporativo.

## Requisitos

- Python 3.10 o superior
- Node.js 18 o superior

## Cómo ejecutarlo

Abre dos terminales.

**1. Backend** (puerto 8000)

```bash
cd backend
python -m venv .venv

# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

La primera vez se crea la base de datos y se cargan los datos de prueba. La documentación interactiva de la API queda en http://localhost:8000/docs.

**2. Frontend** (puerto 5173)

```bash
cd frontend
npm install
npm run dev
```

Abre http://localhost:5173. Si no hay sesión, te lleva a `/login`.

## Cuentas de prueba

| Usuario | Contraseña | Rol |
|---|---|---|
| admin | Admin123! | Administrador |
| rrhh | Rrhh123! | Recursos Humanos |
| contabilidad | Conta123! | Contabilidad |
| inventario | Inventario123! | Gestor de inventario |

La cuenta `inventario` es un extra para probar ese rol. Cambia estas contraseñas antes de usar el sistema con datos reales.

## Qué puede hacer cada rol

| Módulo | Administrador | Inventario | Contabilidad | RRHH |
|---|:-:|:-:|:-:|:-:|
| Ver inventario y buscar productos | sí | sí | sí | sí |
| Crear, editar y eliminar productos | sí | sí | no | no |
| Ventas, compras y reporte PDF mensual | sí | no | sí | no |
| Empleados, horas extra, nómina y reporte PDF | sí | no | no | sí |
| Crear usuarios, asignar roles, habilitar o deshabilitar | sí | no | no | no |

El administrador asigna los roles con casillas de verificación (una persona puede tener varios).

## Fechas y zona horaria

Todas las fechas con hora (ingreso de productos, transacciones, creación de usuarios) se guardan en hora de Nicaragua, UTC-6, y la API las devuelve con el desfase `-06:00`. El frontend las muestra siempre en esa zona, sin importar la del navegador.

## Nómina

Los cálculos están en `backend/crud.py` (sección "RR. HH."):

- Valor de la hora = salario base ÷ 30 días ÷ 8 horas.
- Horas extra pagadas al doble (recargo del 100 %).
- INSS laboral: 7 % del salario bruto.
- IR: tabla progresiva anual aplicada al ingreso anualizado (bruto menos INSS), dividido entre 12.

Son parámetros básicos que dejé como constantes al inicio de esa sección. Confírmalos con la normativa laboral y tributaria vigente antes de usarlos para pagar salarios reales.

## Google Sign-In

El botón ya está en el login y queda desactivado hasta que lo configures:

1. Crea un ID de cliente OAuth (tipo "Aplicación web") en Google Cloud y agrega `http://localhost:5173` como origen autorizado.
2. En `frontend/.env`: `VITE_GOOGLE_CLIENT_ID=tu-id.apps.googleusercontent.com`
3. Antes de iniciar el backend: `GOOGLE_CLIENT_ID=tu-id.apps.googleusercontent.com`

Entra solo quien ya tiene un usuario con ese mismo correo (lo crea el administrador).

## Configuración opcional

| Variable | Dónde | Para qué |
|---|---|---|
| `GSL_SECRET_KEY` | backend | Clave para firmar los JWT. Cámbiala fuera de desarrollo. |
| `GSL_CORS_ORIGINS` | backend | Orígenes extra permitidos, separados por coma. |
| `VITE_API_URL` | frontend | URL de la API (por defecto `http://localhost:8000/api`). |

Para volver a empezar con datos de prueba nuevos, detén el backend y borra `backend/gslsys.db`.

## Estructura

```
GSLsys/
├── backend/   database.py, models.py, schemas.py, crud.py, auth.py, pdf_generator.py, main.py
├── frontend/  src/components, src/pages, src/services
└── README.md
```
