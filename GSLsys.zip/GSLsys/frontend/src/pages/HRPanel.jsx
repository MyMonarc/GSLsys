import { useCallback, useEffect, useState } from 'react'
import { api } from '../services/api'
import { currentMonth, dateOnly, money, todayISO } from '../services/format.js'
import DataTable from '../components/DataTable.jsx'
import Modal from '../components/Modal.jsx'
import Field, { ErrorBox } from '../components/Field.jsx'

const EMPTY_EMP = { full_name: '', position: '', hire_date: '', base_salary: '', is_active: true }

export default function HRPanel() {
  const [tab, setTab] = useState('employees')
  const [period, setPeriod] = useState(currentMonth())
  const [employees, setEmployees] = useState([])
  const [payroll, setPayroll] = useState([])
  const [overtime, setOvertime] = useState([])
  const [error, setError] = useState('')
  const [modal, setModal] = useState(null) // { kind: 'employee' | 'overtime', ... }
  const [formError, setFormError] = useState('')
  const [saving, setSaving] = useState(false)
  const [exporting, setExporting] = useState(false)

  const loadEmployees = useCallback(() => api.employees().then(setEmployees).catch((e) => setError(e.message)), [])
  const loadPeriod = useCallback(() => {
    if (!period) return
    api.payroll(period).then(setPayroll).catch((e) => setError(e.message))
    api.overtime({ period }).then(setOvertime).catch((e) => setError(e.message))
  }, [period])

  useEffect(() => { loadEmployees() }, [loadEmployees])
  useEffect(() => { loadPeriod() }, [loadPeriod])

  const setField = (k, v) => setModal((m) => ({ ...m, form: { ...m.form, [k]: v } }))
  const nameOf = (id) => employees.find((e) => e.id === id)?.full_name || `#${id}`

  const openEmployee = (emp) => {
    setFormError('')
    setModal(emp
      ? { kind: 'employee', id: emp.id, form: { full_name: emp.full_name, position: emp.position, hire_date: emp.hire_date, base_salary: emp.base_salary, is_active: emp.is_active } }
      : { kind: 'employee', form: { ...EMPTY_EMP } })
  }
  const openOvertime = (emp) => {
    setFormError('')
    setModal({ kind: 'overtime', form: { employee_id: emp?.id || employees[0]?.id || '', work_date: todayISO(), hours: '', note: '' } })
  }

  const save = async (e) => {
    e.preventDefault()
    setSaving(true)
    setFormError('')
    const f = modal.form
    try {
      if (modal.kind === 'employee') {
        const body = { ...f, base_salary: Number(f.base_salary) }
        if (modal.id) await api.updateEmployee(modal.id, body)
        else await api.createEmployee(body)
        loadEmployees()
      } else {
        await api.createOvertime({ ...f, employee_id: Number(f.employee_id), hours: Number(f.hours) })
      }
      setModal(null)
      loadPeriod()
    } catch (err) {
      setFormError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const removeOvertime = async (id) => {
    try { await api.deleteOvertime(id); loadPeriod() } catch (err) { setError(err.message) }
  }

  const exportPdf = async () => {
    setExporting(true)
    try { await api.hrPdf(period); setError('') } catch (err) { setError(err.message) } finally { setExporting(false) }
  }

  const empColumns = [
    { key: 'full_name', label: 'Empleado', render: (e) => <span className="font-semibold text-navy">{e.full_name}</span> },
    { key: 'position', label: 'Cargo' },
    { key: 'hire_date', label: 'Fecha de ingreso', render: (e) => dateOnly(e.hire_date) },
    { key: 'base_salary', label: 'Salario base', align: 'right', render: (e) => money(e.base_salary) },
    { key: 'is_active', label: 'Estado', render: (e) => <span className={`badge ${e.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-silver-light text-slate-600'}`}>{e.is_active ? 'Activo' : 'Inactivo'}</span> },
    { key: 'actions', label: 'Acciones', render: (e) => (
      <span className="flex gap-2">
        <button className="btn-ghost btn-sm" onClick={() => openEmployee(e)}>Editar</button>
        <button className="btn-ghost btn-sm" onClick={() => openOvertime(e)}>Horas extra</button>
      </span>
    ) },
  ]

  const payColumns = [
    { key: 'full_name', label: 'Empleado', render: (r) => (<span><span className="font-semibold text-navy">{r.full_name}</span><span className="block text-[11px] text-slate-500">Hora: {money(r.hourly_rate)}</span></span>) },
    { key: 'base_salary', label: 'Salario base', align: 'right', render: (r) => money(r.base_salary) },
    { key: 'overtime_hours', label: 'H. extra', align: 'right' },
    { key: 'overtime_pay', label: 'Pago H. extra (x2)', align: 'right', render: (r) => money(r.overtime_pay) },
    { key: 'gross', label: 'Bruto', align: 'right', render: (r) => money(r.gross) },
    { key: 'inss', label: 'INSS', align: 'right', render: (r) => money(r.inss) },
    { key: 'ir', label: 'IR', align: 'right', render: (r) => money(r.ir) },
    { key: 'net', label: 'Neto', align: 'right', render: (r) => <b>{money(r.net)}</b> },
  ]

  const otColumns = [
    { key: 'work_date', label: 'Fecha', render: (o) => dateOnly(o.work_date) },
    { key: 'employee_id', label: 'Empleado', render: (o) => nameOf(o.employee_id) },
    { key: 'hours', label: 'Horas', align: 'right' },
    { key: 'note', label: 'Nota' },
    { key: 'actions', label: '', render: (o) => <button className="btn-ghost btn-sm text-sport" onClick={() => removeOvertime(o.id)}>Quitar</button> },
  ]

  const tabs = [['employees', 'Empleados'], ['payroll', 'Nómina y horas extra']]

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy">Recursos Humanos</h1>
          <p className="text-sm text-slate-500">Personal, horas extra y cálculo de nómina.</p>
        </div>
        <button className="btn-primary" onClick={exportPdf} disabled={exporting || !period}>{exporting ? 'Generando…' : 'Reporte de empleados y nómina PDF'}</button>
      </div>

      <div className="flex gap-1 border-b border-silver-light" role="tablist">
        {tabs.map(([id, label]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={`-mb-px border-b-2 px-4 py-2 text-sm font-semibold ${tab === id ? 'border-sport text-navy' : 'border-transparent text-slate-500 hover:text-navy'}`}>{label}</button>
        ))}
      </div>

      <ErrorBox message={error} />

      {tab === 'employees' && (
        <>
          <div className="flex justify-end"><button className="btn-navy" onClick={() => openEmployee(null)}>Nuevo empleado</button></div>
          <DataTable columns={empColumns} rows={employees} pageSize={8} empty="Aún no hay empleados." />
        </>
      )}

      {tab === 'payroll' && (
        <>
          <div className="flex flex-wrap items-end justify-between gap-3">
            <Field label="Período de nómina"><input type="month" className="input" value={period} onChange={(e) => setPeriod(e.target.value)} /></Field>
            <button className="btn-navy" onClick={() => openOvertime(null)} disabled={!employees.length}>Registrar horas extra</button>
          </div>
          <DataTable columns={payColumns} rows={payroll} pageSize={8} empty="No hay empleados activos para este período." />
          <p className="rounded-md bg-silver-light/60 p-3 text-xs text-slate-600">
            Hora = salario base ÷ 30 días ÷ 8 horas. Las horas extra se pagan al doble. INSS laboral 7 % sobre el bruto; el IR usa la tabla progresiva anual sobre el ingreso anualizado. Son parámetros básicos: confírmalos con la normativa vigente.
          </p>
          <h2 className="pt-2 text-lg font-bold text-navy">Horas extra del período</h2>
          <DataTable columns={otColumns} rows={overtime} pageSize={6} empty="Sin horas extra registradas en este período." />
        </>
      )}

      {modal?.kind === 'employee' && (
        <Modal title={modal.id ? 'Editar empleado' : 'Nuevo empleado'} onClose={() => setModal(null)}>
          <form onSubmit={save} className="space-y-3">
            <Field label="Nombre completo"><input className="input" required value={modal.form.full_name} onChange={(e) => setField('full_name', e.target.value)} /></Field>
            <Field label="Cargo"><input className="input" required value={modal.form.position} onChange={(e) => setField('position', e.target.value)} /></Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Fecha de ingreso"><input type="date" className="input" required value={modal.form.hire_date} onChange={(e) => setField('hire_date', e.target.value)} /></Field>
              <Field label="Salario base mensual (C$)"><input type="number" min="1" step="0.01" className="input" required value={modal.form.base_salary} onChange={(e) => setField('base_salary', e.target.value)} /></Field>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" className="h-4 w-4 accent-[#E31837]" checked={modal.form.is_active} onChange={(e) => setField('is_active', e.target.checked)} />
              Empleado activo (entra en la nómina)
            </label>
            <ErrorBox message={formError} />
            <div className="flex justify-end gap-2 pt-1">
              <button type="button" className="btn-ghost" onClick={() => setModal(null)}>Cancelar</button>
              <button className="btn-primary" disabled={saving}>{saving ? 'Guardando…' : 'Guardar empleado'}</button>
            </div>
          </form>
        </Modal>
      )}

      {modal?.kind === 'overtime' && (
        <Modal title="Registrar horas extra" onClose={() => setModal(null)}>
          <form onSubmit={save} className="space-y-3">
            <Field label="Empleado">
              <select className="input" required value={modal.form.employee_id} onChange={(e) => setField('employee_id', e.target.value)}>
                {employees.filter((e) => e.is_active).map((e) => <option key={e.id} value={e.id}>{e.full_name}</option>)}
              </select>
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Fecha"><input type="date" className="input" required value={modal.form.work_date} onChange={(e) => setField('work_date', e.target.value)} /></Field>
              <Field label="Horas"><input type="number" className="input" min="0.25" max="24" step="0.25" required value={modal.form.hours} onChange={(e) => setField('hours', e.target.value)} /></Field>
            </div>
            <Field label="Nota (opcional)"><input className="input" value={modal.form.note} onChange={(e) => setField('note', e.target.value)} /></Field>
            <p className="text-xs text-slate-500">Se pagan al doble del valor de la hora ordinaria en el mes de la fecha indicada.</p>
            <ErrorBox message={formError} />
            <div className="flex justify-end gap-2 pt-1">
              <button type="button" className="btn-ghost" onClick={() => setModal(null)}>Cancelar</button>
              <button className="btn-primary" disabled={saving}>{saving ? 'Guardando…' : 'Registrar horas'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
