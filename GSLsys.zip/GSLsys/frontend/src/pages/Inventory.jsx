import { useCallback, useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api } from '../services/api'
import { useAuth } from '../services/auth.jsx'
import { dateTime, money } from '../services/format.js'
import DataTable from '../components/DataTable.jsx'
import Modal from '../components/Modal.jsx'
import Field, { ErrorBox } from '../components/Field.jsx'
import ProductCard from '../components/ProductCard.jsx'

const EMPTY = { sku: '', name: '', category: '', description: '', emoji: '🏷️', price: '', cost: '', stock: '' }

export default function Inventory() {
  const { hasRole } = useAuth()
  const canEdit = hasRole('inventory')
  const [params, setParams] = useSearchParams()
  const search = params.get('q') || ''
  const [category, setCategory] = useState('')
  const [categories, setCategories] = useState([])
  const [page, setPage] = useState(1)
  const [view, setView] = useState(canEdit ? 'table' : 'cards')
  const [data, setData] = useState({ items: [], total: 0, pages: 1, page: 1 })
  const [error, setError] = useState('')
  const [modal, setModal] = useState(null) // { id?, form }
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState('')
  const [toDelete, setToDelete] = useState(null)

  const pageSize = view === 'cards' ? 12 : 8

  const load = useCallback(() => {
    api.products({ search, category, page, page_size: pageSize })
      .then((r) => { setData(r); setError('') })
      .catch((e) => setError(e.message))
  }, [search, category, page, pageSize])

  useEffect(() => { load() }, [load])
  useEffect(() => { api.categories().then(setCategories).catch(() => {}) }, [data.total])
  useEffect(() => { setPage(1) }, [search, category, view])

  const openNew = () => { setFormError(''); setModal({ form: { ...EMPTY } }) }
  const openEdit = (p) => {
    setFormError('')
    setModal({ id: p.id, form: { sku: p.sku, name: p.name, category: p.category, description: p.description || '', emoji: p.emoji || '🏷️', price: p.price, cost: p.cost, stock: p.stock } })
  }
  const setField = (k, v) => setModal((m) => ({ ...m, form: { ...m.form, [k]: v } }))

  const save = async (e) => {
    e.preventDefault()
    setSaving(true)
    setFormError('')
    const f = modal.form
    const body = { ...f, price: Number(f.price), cost: Number(f.cost), stock: parseInt(f.stock, 10) }
    try {
      if (modal.id) await api.updateProduct(modal.id, body)
      else await api.createProduct(body)
      setModal(null)
      load()
    } catch (err) {
      setFormError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const remove = async () => {
    try {
      await api.deleteProduct(toDelete.id)
      setToDelete(null)
      load()
    } catch (err) {
      setError(err.message)
      setToDelete(null)
    }
  }

  const columns = [
    { key: 'name', label: 'Producto', render: (p) => (<span><span className="mr-2">{p.emoji}</span><span className="font-semibold text-navy">{p.name}</span><span className="block text-[11px] text-slate-500">{p.sku}</span></span>) },
    { key: 'category', label: 'Categoría' },
    { key: 'price', label: 'Precio', align: 'right', render: (p) => money(p.price) },
    { key: 'stock', label: 'Stock', align: 'right', render: (p) => <span className={p.stock < 10 ? 'font-bold text-sport' : ''}>{p.stock}</span> },
    { key: 'created_at', label: 'Ingreso (UTC-6)', render: (p) => dateTime(p.created_at) },
    ...(canEdit ? [{ key: 'actions', label: 'Acciones', render: (p) => (
      <span className="flex gap-2">
        <button className="btn-ghost btn-sm" onClick={() => openEdit(p)}>Editar</button>
        <button className="btn-ghost btn-sm text-sport" onClick={() => setToDelete(p)}>Eliminar</button>
      </span>
    ) }] : []),
  ]

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy">Inventario</h1>
          {search && <p className="text-sm text-slate-500">Resultados para “{search}” <button className="font-semibold text-sport hover:underline" onClick={() => setParams({})}>Quitar</button></p>}
        </div>
        {canEdit && <button className="btn-primary" onClick={openNew}>Nuevo producto</button>}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <select className="input w-auto" value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filtrar por categoría">
          <option value="">Todas las categorías</option>
          {categories.map((c) => <option key={c}>{c}</option>)}
        </select>
        <div className="ml-auto inline-flex overflow-hidden rounded-md border border-silver" role="group" aria-label="Vista">
          {[['table', 'Tabla'], ['cards', 'Tarjetas']].map(([v, l]) => (
            <button key={v} onClick={() => setView(v)} aria-pressed={view === v}
              className={`px-3 py-1.5 text-xs font-semibold ${view === v ? 'bg-navy text-white' : 'bg-white text-navy hover:bg-silver-light'}`}>{l}</button>
          ))}
        </div>
      </div>

      <ErrorBox message={error} />

      {view === 'table' ? (
        <DataTable columns={columns} rows={data.items} page={data.page} pages={data.pages} total={data.total} onPage={setPage} empty="No hay productos que coincidan." />
      ) : (
        <>
          {data.items.length === 0 && <p className="py-10 text-center text-sm text-slate-500">No hay productos que coincidan.</p>}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {data.items.map((p) => (
              <ProductCard key={p.id} product={p} actions={canEdit && (<>
                <button className="btn-ghost btn-sm flex-1" onClick={() => openEdit(p)}>Editar</button>
                <button className="btn-ghost btn-sm text-sport" onClick={() => setToDelete(p)}>Eliminar</button>
              </>)} />
            ))}
          </div>
          <div className="flex items-center justify-center gap-3 text-xs text-slate-600">
            <button className="btn-ghost btn-sm" disabled={data.page <= 1} onClick={() => setPage(data.page - 1)}>Anterior</button>
            <span>Página {data.page} de {data.pages} · {data.total} productos</span>
            <button className="btn-ghost btn-sm" disabled={data.page >= data.pages} onClick={() => setPage(data.page + 1)}>Siguiente</button>
          </div>
        </>
      )}

      {modal && (
        <Modal title={modal.id ? 'Editar producto' : 'Nuevo producto'} onClose={() => setModal(null)}>
          <form onSubmit={save} className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="SKU"><input className="input" required value={modal.form.sku} onChange={(e) => setField('sku', e.target.value)} /></Field>
              <Field label="Categoría"><input className="input" required list="cats" value={modal.form.category} onChange={(e) => setField('category', e.target.value)} />
                <datalist id="cats">{categories.map((c) => <option key={c} value={c} />)}</datalist></Field>
            </div>
            <Field label="Nombre"><input className="input" required value={modal.form.name} onChange={(e) => setField('name', e.target.value)} /></Field>
            <Field label="Descripción"><textarea className="input" rows={2} value={modal.form.description} onChange={(e) => setField('description', e.target.value)} /></Field>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Field label="Ícono"><input className="input" maxLength={4} value={modal.form.emoji} onChange={(e) => setField('emoji', e.target.value)} /></Field>
              <Field label="Precio (C$)"><input className="input" type="number" min="0" step="0.01" required value={modal.form.price} onChange={(e) => setField('price', e.target.value)} /></Field>
              <Field label="Costo (C$)"><input className="input" type="number" min="0" step="0.01" required value={modal.form.cost} onChange={(e) => setField('cost', e.target.value)} /></Field>
              <Field label="Stock"><input className="input" type="number" min="0" step="1" required value={modal.form.stock} onChange={(e) => setField('stock', e.target.value)} /></Field>
            </div>
            {!modal.id && <p className="text-xs text-slate-500">La fecha y hora de ingreso se registran automáticamente al guardar.</p>}
            <ErrorBox message={formError} />
            <div className="flex justify-end gap-2 pt-1">
              <button type="button" className="btn-ghost" onClick={() => setModal(null)}>Cancelar</button>
              <button className="btn-primary" disabled={saving}>{saving ? 'Guardando…' : 'Guardar producto'}</button>
            </div>
          </form>
        </Modal>
      )}

      {toDelete && (
        <Modal title="Eliminar producto" onClose={() => setToDelete(null)}>
          <p className="text-sm">¿Eliminar <b>{toDelete.name}</b>? Las transacciones que lo mencionan se conservan sin vínculo al producto.</p>
          <div className="mt-4 flex justify-end gap-2">
            <button className="btn-ghost" onClick={() => setToDelete(null)}>Cancelar</button>
            <button className="btn-primary" onClick={remove}>Eliminar producto</button>
          </div>
        </Modal>
      )}
    </div>
  )
}
