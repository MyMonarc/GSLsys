import { useCallback, useEffect, useState } from 'react'
import { api } from '../services/api'
import { useAuth } from '../services/auth.jsx'
import { dateTime, ROLE_LABELS } from '../services/format.js'
import DataTable from '../components/DataTable.jsx'
import Modal from '../components/Modal.jsx'
import Field, { ErrorBox } from '../components/Field.jsx'

const ROLES = Object.keys(ROLE_LABELS)

function RoleChecks({ value, onChange }) {
  const toggle = (r) => onChange(value.includes(r) ? value.filter((x) => x !== r) : [...value, r])
  return (
    <fieldset>
      <legend className="label">Roles</legend>
      <div className="grid gap-2 sm:grid-cols-2">
        {ROLES.map((r) => (
          <label key={r} className="flex cursor-pointer items-center gap-2 rounded-md border border-silver px-3 py-2 text-sm hover:bg-silver-light/60">
            <input type="checkbox" className="h-4 w-4 accent-[#E31837]" checked={value.includes(r)} onChange={() => toggle(r)} />
            {ROLE_LABELS[r]}
          </label>
        ))}
      </div>
    </fieldset>
  )
}

export default function AdminPanel() {
  const { user: me } = useAuth()
  const [users, setUsers] = useState([])
  const [error, setError] = useState('')
  const [modal, setModal] = useState(null) // { id?, form }
  const [formError, setFormError] = useState('')
  const [saving, setSaving] = useState(false)

  const load = useCallback(() => api.users().then(setUsers).catch((e) => setError(e.message)), [])
  useEffect(() => { load() }, [load])

  const setField = (k, v) => setModal((m) => ({ ...m, form: { ...m.form, [k]: v } }))
  const openNew = () => { setFormError(''); setModal({ form: { username: '', full_name: '', email: '', password: '', roles: [] } }) }
  const openEdit = (u) => { setFormError(''); setModal({ id: u.id, username: u.username, form: { full_name: u.full_name, email: u.email || '', password: '', roles: [...u.roles] } }) }

  const save = async (e) => {
    e.preventDefault()
    setSaving(true)
    setFormError('')
    try {
      if (modal.id) {
        const body = { full_name: modal.form.full_name, email: modal.form.email, roles: modal.form.roles }
        if (modal.form.password) body.password = modal.form.password
        await api.updateUser(modal.id, body)
      } else {
        await api.createUser(modal.form)
      }
      setModal(null)
      load()
    } catch (err) {
      setFormError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const toggleActive = async (u) => {
    try {
      await api.updateUser(u.id, { is_active: !u.is_active })
      setError('')
      load()
    } catch (err) {
      setError(err.message)
    }
  }

  const columns = [
    { key: 'full_name', label: 'Usuario', render: (u) => (<span><span className="font-semibold text-navy">{u.full_name}</span><span className="block text-[11px] text-slate-500">{u.username}{u.email ? ` · ${u.email}` : ''}</span></span>) },
    { key: 'roles', label: 'Roles', render: (u) => (
      <span className="flex flex-wrap gap-1">{u.roles.length ? u.roles.map((r) => <span key={r} className="badge bg-silver-light text-navy">{ROLE_LABELS[r]}</span>) : <span className="text-xs text-slate-400">Sin roles</span>}</span>
    ) },
    { key: 'is_active', label: 'Estado', render: (u) => <span className={`badge ${u.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-sport/10 text-sport-dark'}`}>{u.is_active ? 'Habilitado' : 'Deshabilitado'}</span> },
    { key: 'created_at', label: 'Creado', render: (u) => dateTime(u.created_at) },
    { key: 'actions', label: 'Acciones', render: (u) => (
      <span className="flex gap-2">
        <button className="btn-ghost btn-sm" onClick={() => openEdit(u)}>Editar</button>
        <button className="btn-ghost btn-sm" disabled={u.id === me.id} onClick={() => toggleActive(u)}>{u.is_active ? 'Deshabilitar' : 'Habilitar'}</button>
      </span>
    ) },
  ]

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy">Administración de usuarios</h1>
          <p className="text-sm text-slate-500">Crea cuentas, asigna roles y habilita o deshabilita el acceso.</p>
        </div>
        <button className="btn-primary" onClick={openNew}>Nuevo usuario</button>
      </div>
      <ErrorBox message={error} />
      <DataTable columns={columns} rows={users} pageSize={8} empty="No hay usuarios." />

      {modal && (
        <Modal title={modal.id ? `Editar a ${modal.username}` : 'Nuevo usuario'} onClose={() => setModal(null)}>
          <form onSubmit={save} className="space-y-3">
            {!modal.id && <Field label="Nombre de usuario"><input className="input" required minLength={3} value={modal.form.username} onChange={(e) => setField('username', e.target.value)} /></Field>}
            <Field label="Nombre completo"><input className="input" required value={modal.form.full_name} onChange={(e) => setField('full_name', e.target.value)} /></Field>
            <Field label="Correo" hint="Necesario si la persona entrará con Google."><input className="input" type="email" value={modal.form.email} onChange={(e) => setField('email', e.target.value)} /></Field>
            <Field label={modal.id ? 'Nueva contraseña (opcional)' : 'Contraseña'} hint="Entre 6 y 72 caracteres.">
              <input className="input" type="password" autoComplete="new-password" minLength={6} maxLength={72} required={!modal.id} value={modal.form.password} onChange={(e) => setField('password', e.target.value)} />
            </Field>
            <RoleChecks value={modal.form.roles} onChange={(v) => setField('roles', v)} />
            <ErrorBox message={formError} />
            <div className="flex justify-end gap-2 pt-1">
              <button type="button" className="btn-ghost" onClick={() => setModal(null)}>Cancelar</button>
              <button className="btn-primary" disabled={saving}>{saving ? 'Guardando…' : modal.id ? 'Guardar cambios' : 'Crear usuario'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
