import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../services/auth.jsx'
import GoogleSignInButton from '../components/GoogleSignInButton.jsx'
import { ErrorBox } from '../components/Field.jsx'
import { Logo } from '../components/Navbar.jsx'

export default function Login() {
  const { login, loginGoogle } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ username: '', password: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const dest = location.state?.from?.pathname || '/'

  const run = async (fn) => {
    setBusy(true)
    setError('')
    try {
      await fn()
      navigate(dest, { replace: true })
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const submit = (e) => {
    e.preventDefault()
    run(() => login(form.username, form.password))
  }

  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <section className="flex flex-col justify-between bg-navy p-8 text-white md:p-12">
        <Logo />
        <div className="my-10 max-w-md">
          <h1 className="text-3xl font-black leading-tight sm:text-4xl">Todo el equipo de Granada SportLine en un solo sistema.</h1>
          <p className="mt-4 text-sm text-silver">
            Inventario deportivo, equipo de streaming, finanzas y personal, con acceso según tu rol.
          </p>
        </div>
        <div className="h-1.5 w-24 rounded bg-sport" />
      </section>

      <section className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-bold text-navy">Iniciar sesión</h2>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="label" htmlFor="u">Usuario</label>
              <input id="u" className="input" autoComplete="username" required value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="p">Contraseña</label>
              <input id="p" type="password" className="input" autoComplete="current-password" required value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
            <ErrorBox message={error} />
            <button className="btn-primary w-full" disabled={busy}>{busy ? 'Entrando…' : 'Entrar'}</button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-slate-400">
            <span className="h-px flex-1 bg-silver-light" />o<span className="h-px flex-1 bg-silver-light" />
          </div>
          <GoogleSignInButton onCredential={(c) => run(() => loginGoogle(c))} onError={setError} />

          <div className="mt-8 rounded-md bg-silver-light/60 p-3 text-xs text-slate-600">
            <p className="mb-1 font-semibold text-navy">Cuentas de prueba (datos iniciales)</p>
            <p>admin / Admin123!</p>
            <p>rrhh / Rrhh123!</p>
            <p>contabilidad / Conta123!</p>
            <p>inventario / Inventario123!</p>
          </div>
        </div>
      </section>
    </div>
  )
}
