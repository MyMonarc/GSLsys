import { useCallback, useEffect, useState } from 'react'
import { api } from '../services/api'
import { currentMonth, dateTime, money } from '../services/format.js'
import DataTable from '../components/DataTable.jsx'
import Modal from '../components/Modal.jsx'
import Field, { ErrorBox } from '../components/Field.jsx'

const NEW_TX = { type: 'venta', description: '', product_id: '', quantity: 1, amount: '' }

export default function AccountingPanel() {
  const [month, setMonth] = useState(currentMonth())
  const [type, setType] = useState('')
  const [page, setPage] = useState(1)
  const [data, setData] = useState({ items: [], total: 0, pages: 1, page: 1, total_ventas: 0, total_compras: 0 })
  const [products, setProducts] = useState([])
  const [error, setError] = useState('')
  const [modal, setModal] = useState(null)
  const [formError, setFormError] = useState('')
  const [saving, setSaving] = useState(false)
  const [exporting, setExporting] = useState(false)

  const load = useCallback(() => {
    if (!month) return
    api.transactions({ month, type, page, page_size: 8 })
      .then((r) => { setData(r); setError('') })
      .catch((e) => setError(e.message))
  }, [month, type, page])

  useEffect(() => { load() }, [load])
  useEffect(() => { setPage(1) }, [month, type])
  useEffect(() => { api.products({ page: 1, page_size: 100 }).then((r) => setProducts(r.items)).catch(() => {}) }, [])

  const setField = (k, v) => setModal((m) => ({ ...m, [k]: v }))
  const selected = products.find((p) => String(p.id) === String(modal?.product_id))
  const suggested = selected ? (modal.type === 'venta' ? selected.price : selected.cost) * (Number(modal.quantity) || 0) : null

  const save = async (e) => {
    e.preventDefault()
    setSaving(true)
    setFormError('')
    const body = {
      type: modal.type,
      description: modal.description,
      quantity: parseInt(modal.quantity, 10) || 1,
      product_id: modal.product_id ? Number(modal.product_id) : null,
      amount: modal.amount === '' ? null : Number(modal.amount),
    }
    try {
      await api.createTransaction(body)
      setModal(null)
      load()
      api.products({ page: 1, page_size: 100 }).then((r) => setProducts(r.items)).catch(() => {})
    } catch (err) {
      setFormError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const exportPdf = async () => {
    setExporting(true)
    try { await api.accountingPdf(month); setError('') } catch (err) { setError(err.message) } finally { setExporting(false) }
  }

  const balance = data.total_ventas - data.total_compras
  const columns = [
    { key: 'created_at', label: 'Fecha y hora (UTC-6)', render: (t) => dateTime(t.created_at) },
    { key: 'type', label: 'Tipo', render: (t) => <span className={`badge ${t.type === 'venta' ? 'bg-emerald-100 text-emerald-800' : 'bg-navy/10 text-navy'}`}>{t.type === 'venta' ? 'Venta' : 'Compra'}</span> },
    { key: 'description', label: 'Descripción', render: (t) => (<span>{t.description}{t.quantity > 1 && <span className="text-slate-500"> × {t.quantity}</span>}</span>) },
    { key: 'user_name', label: 'Registrado por' },
    { key: 'amount', label: 'Monto', align: 'right', render: (t) => <b>{money(t.amount)}</b> },
  ]

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy">Contabilidad</h1>
          <p className="text-sm text-slate-500">Ventas y compras del período, con usuario y hora de cada registro.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-navy" onClick={() => { setFormError(''); setModal({ ...NEW_TX }) }}>Nueva transacción</button>
          <button className="btn-primary" onClick={exportPdf} disabled={exporting || !month}>{exporting ? 'Generando…' : 'Reporte mensual PDF'}</button>
        </div>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <Field label="Período"><input type="month" className="input" value={month} onChange={(e) => setMonth(e.target.value)} /></Field>
        <Field label="Tipo">
          <select className="input" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">Ventas y compras</option>
            <option value="venta">Solo ventas</option>
            <option value="compra">Solo compras</option>
          </select>
        </Field>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="card border-l-4 border-l-navy p-4"><p className="text-xs font-semibold text-slate-500">Ventas</p><p className="text-2xl font-extrabold text-navy">{money(data.total_ventas)}</p></div>
        <div className="card border-l-4 border-l-navy p-4"><p className="text-xs font-semibold text-slate-500">Compras</p><p className="text-2xl font-extrabold text-navy">{money(data.total_compras)}</p></div>
        <div className="card border-l-4 border-l-sport p-4"><p className="text-xs font-semibold text-slate-500">Balance</p><p className={`text-2xl font-extrabold ${balance < 0 ? 'text-sport' : 'text-navy'}`}>{money(balance)}</p></div>
      </div>

      <ErrorBox message={error} />
      <DataTable columns={columns} rows={data.items} page={data.page} pages={data.pages} total={data.total} onPage={setPage} empty="No hay transacciones en este período." />

      {modal && (
        <Modal title="Nueva transacción" onClose={() => setModal(null)}>
          <form onSubmit={save} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Tipo">
                <select className="input" value={modal.type} onChange={(e) => setField('type', e.target.value)}>
                  <option value="venta">Venta</option>
                  <option value="compra">Compra</option>
                </select>
              </Field>
              <Field label="Cantidad"><input className="input" type="number" min="1" step="1" required value={modal.quantity} onChange={(e) => setField('quantity', e.target.value)} /></Field>
            </div>
            <Field label="Producto (opcional)" hint="Una venta descuenta del stock y una compra lo aumenta.">
              <select className="input" value={modal.product_id} onChange={(e) => setField('product_id', e.target.value)}>
                <option value="">Sin producto</option>
                {products.map((p) => <option key={p.id} value={p.id}>{p.name} (stock {p.stock})</option>)}
              </select>
            </Field>
            <Field label="Descripción"><input className="input" required minLength={2} value={modal.description} onChange={(e) => setField('description', e.target.value)} /></Field>
            <Field label="Monto (C$)" hint={suggested !== null ? `Si lo dejas vacío se usa ${money(suggested)} según el producto.` : 'Obligatorio si no eliges un producto.'}>
              <input className="input" type="number" min="0.01" step="0.01" required={!modal.product_id} value={modal.amount} onChange={(e) => setField('amount', e.target.value)} />
            </Field>
            <p className="text-xs text-slate-500">Se registra con tu usuario y la hora actual de Nicaragua (UTC-6).</p>
            <ErrorBox message={formError} />
            <div className="flex justify-end gap-2 pt-1">
              <button type="button" className="btn-ghost" onClick={() => setModal(null)}>Cancelar</button>
              <button className="btn-primary" disabled={saving}>{saving ? 'Guardando…' : 'Registrar'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
