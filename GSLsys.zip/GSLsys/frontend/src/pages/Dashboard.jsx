import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../services/api'
import { useAuth } from '../services/auth.jsx'
import { money } from '../services/format.js'
import ProductCard from '../components/ProductCard.jsx'
import { ErrorBox } from '../components/Field.jsx'

function Kpi({ label, value, to, accent }) {
  const body = (
    <div className={`card h-full border-l-4 p-4 ${accent ? 'border-l-sport' : 'border-l-navy'}`}>
      <p className="text-xs font-semibold text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-extrabold text-navy">{value}</p>
    </div>
  )
  return to ? <Link to={to} className="block hover:opacity-90">{body}</Link> : body
}

export default function Dashboard() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [recent, setRecent] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    api.dashboard().then(setData).catch((e) => setError(e.message))
    api.products({ page: 1, page_size: 8 }).then((r) => setRecent(r.items)).catch(() => {})
  }, [])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-navy">Hola, {user.full_name.split(' (')[0]}</h1>
        <p className="text-sm text-slate-500">Resumen del día en Granada SportLine.</p>
      </div>
      <ErrorBox message={error} />

      {data && (
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Kpi label="Productos en catálogo" value={data.products} to="/inventory" />
          <Kpi label="Con poco stock" value={data.low_stock} accent={data.low_stock > 0} to="/inventory" />
          {data.finance && <Kpi label="Ventas del mes" value={money(data.finance.total_ventas)} to="/accounting" />}
          {data.finance && <Kpi label="Compras del mes" value={money(data.finance.total_compras)} to="/accounting" />}
          {data.employees !== null && <Kpi label="Empleados activos" value={data.employees} to="/hr" />}
          {data.users !== null && <Kpi label="Usuarios del sistema" value={data.users} to="/admin" />}
        </div>
      )}

      {data?.low_stock_items?.length > 0 && (
        <section className="card border-l-4 border-l-sport p-4">
          <h2 className="text-sm font-bold text-navy">Para reponer pronto</h2>
          <ul className="mt-2 grid gap-1 text-sm sm:grid-cols-2">
            {data.low_stock_items.map((p) => (
              <li key={p.id} className="flex justify-between gap-3">
                <span>{p.emoji} {p.name}</span>
                <span className="font-semibold text-sport">{p.stock} uds.</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-lg font-bold text-navy">Últimos productos ingresados</h2>
          <Link to="/inventory" className="text-sm font-semibold text-sport hover:underline">Ver inventario</Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {recent.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </div>
  )
}
