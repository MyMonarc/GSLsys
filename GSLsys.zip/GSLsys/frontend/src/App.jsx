import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Inventory from './pages/Inventory.jsx'
import AdminPanel from './pages/AdminPanel.jsx'
import HRPanel from './pages/HRPanel.jsx'
import AccountingPanel from './pages/AccountingPanel.jsx'
import { useAuth } from './services/auth.jsx'

function Protected({ roles }) {
  const { user, loading, hasRole } = useAuth()
  const location = useLocation()
  if (loading) return <div className="p-10 text-center text-sm text-slate-500">Cargando…</div>
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />
  if (roles && !hasRole(...roles)) {
    return (
      <div className="mx-auto max-w-lg p-10 text-center">
        <h1 className="text-xl font-bold text-navy">Sin acceso</h1>
        <p className="mt-2 text-sm text-slate-600">Tu cuenta no tiene permiso para ver este módulo.</p>
      </div>
    )
  }
  return <Outlet />
}

function Layout() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="mx-auto w-full max-w-7xl px-3 py-5 sm:px-5">
        <Outlet />
      </main>
    </div>
  )
}

export default function App() {
  const { user, loading } = useAuth()
  return (
    <Routes>
      <Route path="/login" element={!loading && user ? <Navigate to="/" replace /> : <Login />} />
      <Route element={<Protected />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route element={<Protected roles={['admin']} />}>
            <Route path="/admin" element={<AdminPanel />} />
          </Route>
          <Route element={<Protected roles={['hr']} />}>
            <Route path="/hr" element={<HRPanel />} />
          </Route>
          <Route element={<Protected roles={['accounting']} />}>
            <Route path="/accounting" element={<AccountingPanel />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
