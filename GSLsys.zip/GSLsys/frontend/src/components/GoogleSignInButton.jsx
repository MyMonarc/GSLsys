// Botón "Iniciar sesión con Google" (Google Identity Services).
// Se activa solo si defines VITE_GOOGLE_CLIENT_ID en frontend/.env y GOOGLE_CLIENT_ID en el backend.
import { useEffect, useRef, useState } from 'react'

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID
const SRC = 'https://accounts.google.com/gsi/client'

export default function GoogleSignInButton({ onCredential, onError }) {
  const ref = useRef(null)
  const cb = useRef({ onCredential, onError })
  const [ready, setReady] = useState(false)
  cb.current = { onCredential, onError }

  useEffect(() => {
    if (!CLIENT_ID) return
    const init = () => {
      window.google.accounts.id.initialize({
        client_id: CLIENT_ID,
        callback: (resp) => cb.current.onCredential(resp.credential),
      })
      window.google.accounts.id.renderButton(ref.current, { theme: 'outline', size: 'large', width: 320, text: 'signin_with' })
      setReady(true)
    }
    if (window.google?.accounts?.id) return init()
    let script = document.querySelector(`script[src="${SRC}"]`)
    if (!script) {
      script = document.createElement('script')
      script.src = SRC
      script.async = true
      document.head.appendChild(script)
    }
    script.addEventListener('load', init)
    script.addEventListener('error', () => cb.current.onError?.('No se pudo cargar Google Sign-In'))
    return () => script.removeEventListener('load', init)
  }, [])

  if (!CLIENT_ID) {
    return (
      <button type="button" disabled className="btn-ghost w-full" title="Define VITE_GOOGLE_CLIENT_ID para activarlo">
        <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden="true">
          <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z" />
          <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z" />
          <path fill="#FBBC05" d="M10.5 28.7a14.5 14.5 0 0 1 0-9.4l-7.9-6.1a24 24 0 0 0 0 21.6l7.9-6.1z" />
          <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.9 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z" />
        </svg>
        Continuar con Google (sin configurar)
      </button>
    )
  }
  return <div ref={ref} className={`flex justify-center ${ready ? '' : 'min-h-[44px]'}`} />
}
