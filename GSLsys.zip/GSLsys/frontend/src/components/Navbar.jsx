import { useEffect, useRef, useState } from 'react'
import { NavLink, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../services/auth.jsx'
import { ROLE_LABELS } from '../services/format.js'

export function Logo({ className = '' }) {
  return (
    <span className={`flex items-center gap-2 ${className}`}>
      <span className="flex h-9 items-center rounded bg-sport px-2 text-lg font-black tracking-tight text-white">GSL</span>
      <span className="leading-tight">
        <span className="block text-sm font-extrabold tracking-wide text-white">GRANADA SPORTLINE</span>
        <span className="block text-[10px] text-silver">GSLsys.com</span>
      </span>
    </span>
  )
}

export default function Navbar() {
  const { user, logout, hasRole } = useAuth()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [q, setQ] = useState(params.get('q') || '')
  const [open, setOpen] = useState(false)
  const box = useRef(null)

  useEffect(() => {
    const close = (e) => box.current && !box.current.contains(e.target) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  const search = (e) => {
    e.preventDefault()
    navigate(`/inventory${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ''}`)
  }

  const links = [
    { to: '/', label: 'Inicio', show: true, end: true },
    { to: '/inventory', label: 'Inventario', show: true },
    { to: '/accounting', label: 'Contabilidad', show: hasRole('accounting') },
    { to: '/hr', label: 'Recursos Humanos', show: hasRole('hr') },
    { to: '/admin', label: 'Administración', show: hasRole('admin') },
  ].filter((l) => l.show)

  return (
    <header className="sticky top-0 z-40 shadow">
      <div className="bg-navy">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-4 gap-y-2 px-3 py-2 sm:px-5">
          <NavLink to="/" aria-label="Ir al inicio"><Logo /></NavLink>

          <form onSubmit={search} className="order-3 flex w-full overflow-hidden rounded-md md:order-none md:w-auto md:flex-1" role="search">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar productos, SKU o categorías"
              aria-label="Buscar productos"
              className="w-full min-w-0 bg-white px-3 py-2 text-sm text-slate-800 placeholder:text-slate-500 focus:outline-none"
            />
            <button className="bg-sport px-4 text-sm font-bold text-white hover:bg-sport-dark" type="submit">Buscar</button>
          </form>

          <div className="relative ml-auto md:ml-0" ref={box}>
            <button
              onClick={() => setOpen((o) => !o)}
              className="flex items-center gap-2 rounded px-2 py-1 text-left text-white hover:bg-navy-700"
              aria-expanded={open}
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-silver-light text-sm font-bold text-navy">
                {user.full_name.slice(0, 1)}
              </span>
              <span className="hidden leading-tight sm:block">
                <span className="block text-[11px] text-silver">Hola,</span>
                <span className="block max-w-[10rem] truncate text-sm font-semibold">{user.full_name.split(' (')[0]}</span>
              </span>
            </button>
            {open && (
              <div className="absolute right-0 mt-2 w-64 rounded-lg border border-silver-light bg-white p-3 text-sm shadow-lg">
                <p className="font-bold text-navy">{user.full_name}</p>
                <p className="text-xs text-slate-500">{user.email || user.username}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {user.roles.map((r) => (
                    <span key={r} className="badge bg-silver-light text-navy">{ROLE_LABELS[r] || r}</span>
                  ))}
                </div>
                <button onClick={logout} className="btn-primary mt-3 w-full">Cerrar sesión</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <nav className="bg-navy-700" aria-label="Módulos">
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-3 sm:px-5">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `whitespace-nowrap border-b-2 px-3 py-2 text-sm font-semibold ${
                  isActive ? 'border-sport text-white' : 'border-transparent text-silver hover:text-white'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </header>
  )
}
