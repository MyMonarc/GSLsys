import { dateTime, money } from '../services/format.js'

export default function ProductCard({ product, actions }) {
  const low = product.stock < 10
  return (
    <article className="card flex flex-col overflow-hidden">
      <div className="flex h-28 items-center justify-center bg-silver-light text-5xl" aria-hidden="true">{product.emoji}</div>
      <div className="flex flex-1 flex-col p-3">
        <p className="text-[11px] font-semibold text-slate-500">{product.category} · {product.sku}</p>
        <h3 className="mt-0.5 line-clamp-2 text-sm font-bold text-navy">{product.name}</h3>
        <p className="mt-2 text-lg font-extrabold text-sport">{money(product.price)}</p>
        <p className={`text-xs font-semibold ${low ? 'text-sport' : 'text-emerald-700'}`}>
          {product.stock === 0 ? 'Agotado' : low ? `Quedan ${product.stock}` : `${product.stock} disponibles`}
        </p>
        <p className="mt-1 text-[11px] text-slate-500">Ingreso: {dateTime(product.created_at)}</p>
        {actions && <div className="mt-3 flex gap-2">{actions}</div>}
      </div>
    </article>
  )
}
