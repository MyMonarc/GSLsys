// Tabla con paginación. Con `pages`/`onPage` la paginación la maneja el servidor;
// si solo pasas `rows`, pagina en el navegador con `pageSize`.
import { useState } from 'react'

export default function DataTable({ columns, rows, empty = 'Sin registros', page, pages, total, onPage, pageSize = 8, footer }) {
  const [localPage, setLocalPage] = useState(1)
  const server = typeof onPage === 'function'
  const totalPages = server ? pages : Math.max(1, Math.ceil(rows.length / pageSize))
  const current = server ? page : Math.min(localPage, totalPages)
  const shown = server ? rows : rows.slice((current - 1) * pageSize, current * pageSize)
  const go = (p) => (server ? onPage(p) : setLocalPage(p))
  const count = server ? total : rows.length

  return (
    <div className="card overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-navy text-xs text-white">
            <tr>
              {columns.map((c) => (
                <th key={c.key} className={`px-3 py-2.5 font-semibold ${c.align === 'right' ? 'text-right' : ''}`}>{c.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {shown.length === 0 && (
              <tr><td colSpan={columns.length} className="px-3 py-8 text-center text-slate-500">{empty}</td></tr>
            )}
            {shown.map((row, i) => (
              <tr key={row.id ?? i} className="border-t border-silver-light even:bg-silver-light/40">
                {columns.map((c) => (
                  <td key={c.key} className={`px-3 py-2.5 align-middle ${c.align === 'right' ? 'text-right tabular-nums' : ''}`}>
                    {c.render ? c.render(row) : row[c.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
          {footer}
        </table>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-silver-light bg-white px-3 py-2 text-xs text-slate-600">
        <span>{count} registro{count === 1 ? '' : 's'}</span>
        <div className="flex items-center gap-2">
          <button className="btn-ghost btn-sm" disabled={current <= 1} onClick={() => go(current - 1)}>Anterior</button>
          <span>Página {current} de {totalPages}</span>
          <button className="btn-ghost btn-sm" disabled={current >= totalPages} onClick={() => go(current + 1)}>Siguiente</button>
        </div>
      </div>
    </div>
  )
}
