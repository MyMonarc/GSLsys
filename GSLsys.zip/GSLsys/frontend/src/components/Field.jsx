export default function Field({ label, children, hint }) {
  return (
    <label className="block">
      <span className="label">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-slate-500">{hint}</span>}
    </label>
  )
}

export function ErrorBox({ message }) {
  if (!message) return null
  return (
    <div role="alert" className="rounded-md border border-sport/40 bg-sport/10 px-3 py-2 text-sm font-medium text-sport-dark">
      {message}
    </div>
  )
}
