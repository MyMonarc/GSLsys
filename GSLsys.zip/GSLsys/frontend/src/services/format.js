const TZ = 'America/Managua' // UTC-6 todo el año

export const money = (n) =>
  'C$ ' + Number(n || 0).toLocaleString('es-NI', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export const dateTime = (iso) =>
  iso
    ? new Date(iso).toLocaleString('es-NI', {
        timeZone: TZ, day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
      })
    : ''

export const dateOnly = (iso) => {
  if (!iso) return ''
  const [y, m, d] = iso.slice(0, 10).split('-')
  return `${d}/${m}/${y}`
}

export const currentMonth = () =>
  new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit' }).format(new Date()).slice(0, 7)

export const todayISO = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date())

export const ROLE_LABELS = {
  admin: 'Administrador',
  inventory: 'Gestor de inventario',
  accounting: 'Contabilidad',
  hr: 'Recursos Humanos',
}
