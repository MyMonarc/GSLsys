// Cliente HTTP de GSLsys. La URL del backend se puede cambiar con VITE_API_URL.
const BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'
const TOKEN_KEY = 'gsl_token'

export const getToken = () => localStorage.getItem(TOKEN_KEY)
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY))

function errorMessage(data, status) {
  const d = data?.detail
  if (typeof d === 'string') return d
  if (Array.isArray(d)) {
    return d.map((e) => `${(e.loc || []).slice(1).join('.')}: ${e.msg}`).join(' | ')
  }
  return `Error ${status}`
}

async function request(path, { method = 'GET', body, params, blob = false } = {}) {
  const headers = {}
  const token = getToken()
  if (token) headers.Authorization = `Bearer ${token}`
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  let url = BASE + path
  if (params) {
    const qs = new URLSearchParams()
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') qs.append(k, v)
    })
    const s = qs.toString()
    if (s) url += '?' + s
  }

  let res
  try {
    res = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined })
  } catch {
    throw new Error('No se pudo conectar con el servidor. ¿Está encendido el backend (puerto 8000)?')
  }

  if (res.status === 401 && !path.startsWith('/auth/')) {
    window.dispatchEvent(new Event('gsl:unauthorized'))
  }
  if (!res.ok) {
    let data = null
    try { data = await res.json() } catch { /* sin cuerpo */ }
    throw new Error(errorMessage(data, res.status))
  }
  if (res.status === 204) return null
  return blob ? res.blob() : res.json()
}

export async function downloadPdf(path, params, filename) {
  const blob = await request(path, { params, blob: true })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export const api = {
  login: (username, password) => request('/auth/login', { method: 'POST', body: { username, password } }),
  loginGoogle: (credential) => request('/auth/google', { method: 'POST', body: { credential } }),
  me: () => request('/auth/me'),
  dashboard: () => request('/dashboard'),

  users: () => request('/users'),
  createUser: (body) => request('/users', { method: 'POST', body }),
  updateUser: (id, body) => request(`/users/${id}`, { method: 'PATCH', body }),

  products: (params) => request('/products', { params }),
  categories: () => request('/categories'),
  createProduct: (body) => request('/products', { method: 'POST', body }),
  updateProduct: (id, body) => request(`/products/${id}`, { method: 'PUT', body }),
  deleteProduct: (id) => request(`/products/${id}`, { method: 'DELETE' }),

  transactions: (params) => request('/transactions', { params }),
  createTransaction: (body) => request('/transactions', { method: 'POST', body }),
  accountingPdf: (month) => downloadPdf('/reports/accounting.pdf', { month }, `GSL_ventas_compras_${month}.pdf`),

  employees: () => request('/employees'),
  createEmployee: (body) => request('/employees', { method: 'POST', body }),
  updateEmployee: (id, body) => request(`/employees/${id}`, { method: 'PUT', body }),
  overtime: (params) => request('/overtime', { params }),
  createOvertime: (body) => request('/overtime', { method: 'POST', body }),
  deleteOvertime: (id) => request(`/overtime/${id}`, { method: 'DELETE' }),
  payroll: (period) => request('/payroll', { params: { period } }),
  hrPdf: (period) => downloadPdf('/reports/hr.pdf', { period }, `GSL_empleados_nomina_${period}.pdf`),
}
