import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api, getToken, setToken } from './api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(!!getToken())

  const logout = useCallback(() => {
    setToken(null)
    setUser(null)
  }, [])

  // Al abrir la app: si hay un token guardado, se valida contra el servidor.
  useEffect(() => {
    if (!getToken()) return
    api.me().then(setUser).catch(logout).finally(() => setLoading(false))
  }, [logout])

  // Cualquier respuesta 401 cierra la sesión y manda al login (ProtectedRoute).
  useEffect(() => {
    window.addEventListener('gsl:unauthorized', logout)
    return () => window.removeEventListener('gsl:unauthorized', logout)
  }, [logout])

  const startSession = (data) => {
    setToken(data.access_token)
    setUser(data.user)
    return data.user
  }

  const value = useMemo(
    () => ({
      user,
      loading,
      login: async (username, password) => startSession(await api.login(username, password)),
      loginGoogle: async (credential) => startSession(await api.loginGoogle(credential)),
      logout,
      // El administrador tiene acceso a todo.
      hasRole: (...roles) => !!user && (user.roles.includes('admin') || roles.some((r) => user.roles.includes(r))),
    }),
    [user, loading, logout],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
