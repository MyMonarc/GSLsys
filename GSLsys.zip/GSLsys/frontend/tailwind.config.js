/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: '#0A2240', 700: '#002D62', 900: '#06152A' },
        sport: { DEFAULT: '#E31837', dark: '#B8102A' },
        silver: { DEFAULT: '#C0C0C0', light: '#E5E7EB' },
      },
      fontFamily: {
        sans: ['"Segoe UI"', 'Roboto', '"Helvetica Neue"', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
