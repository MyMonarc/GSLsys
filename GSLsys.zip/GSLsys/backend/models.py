from sqlalchemy import Boolean, Column, Date, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from database import Base, NITime, now_ni


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(120), unique=True, nullable=True)
    full_name = Column(String(120), nullable=False)
    hashed_password = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    roles_csv = Column(String(100), default="", nullable=False)
    created_at = Column(NITime, default=now_ni, nullable=False)

    @property
    def roles(self):
        return [r for r in (self.roles_csv or "").split(",") if r]

    @roles.setter
    def roles(self, value):
        self.roles_csv = ",".join(sorted(set(value)))


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    sku = Column(String(30), unique=True, index=True, nullable=False)
    name = Column(String(150), index=True, nullable=False)
    category = Column(String(60), index=True, nullable=False)
    description = Column(Text, default="")
    emoji = Column(String(8), default="🏷️")
    price = Column(Float, nullable=False)  # precio de venta (C$)
    cost = Column(Float, nullable=False)   # costo de compra (C$)
    stock = Column(Integer, default=0, nullable=False)
    # Fecha y hora exacta de ingreso al sistema (UTC-6)
    created_at = Column(NITime, default=now_ni, nullable=False)


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    type = Column(String(10), index=True, nullable=False)  # "venta" | "compra"
    description = Column(String(250), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=True)
    quantity = Column(Integer, default=1, nullable=False)
    amount = Column(Float, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(NITime, default=now_ni, index=True, nullable=False)

    user = relationship("User")
    product = relationship("Product")

    @property
    def user_name(self):
        return self.user.full_name if self.user else ""

    @property
    def product_name(self):
        return self.product.name if self.product else None


class Employee(Base):
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String(120), nullable=False)
    position = Column(String(100), nullable=False)
    hire_date = Column(Date, nullable=False)
    base_salary = Column(Float, nullable=False)  # salario mensual en C$
    is_active = Column(Boolean, default=True, nullable=False)

    overtime = relationship("Overtime", cascade="all, delete-orphan", back_populates="employee")


class Overtime(Base):
    __tablename__ = "overtime"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    work_date = Column(Date, nullable=False, index=True)
    hours = Column(Float, nullable=False)
    note = Column(String(200), default="")

    employee = relationship("Employee", back_populates="overtime")
