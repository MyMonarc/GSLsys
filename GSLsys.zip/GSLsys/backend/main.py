"""GSLsys.com - API de Granada SportLine.

Arranque:  uvicorn main:app --reload --port 8000
Documentación interactiva: http://localhost:8000/docs
"""
import json
import os
import urllib.parse
import urllib.request
from contextlib import asynccontextmanager
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from sqlalchemy.orm import Session

import auth
import crud
import models
import pdf_generator
import schemas
from database import Base, SessionLocal, engine, get_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)  # crea gslsys.db si no existe
    with SessionLocal() as db:
        crud.seed_data(db)
    yield


app = FastAPI(title="GSLsys.com - Granada SportLine", version="1.0.0", lifespan=lifespan)

# CORS: orígenes del frontend de desarrollo (Vite). Se pueden añadir más con GSL_CORS_ORIGINS="https://a.com,https://b.com"
origins = ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:4173", "http://127.0.0.1:4173"]
origins += [o.strip() for o in os.getenv("GSL_CORS_ORIGINS", "").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)


@app.exception_handler(crud.CrudError)
async def crud_error_handler(request, exc: crud.CrudError):
    return JSONResponse(status_code=exc.status, content={"detail": exc.message})


# ---------------------------------------------------------------- autenticación
@app.post("/api/auth/login", response_model=schemas.TokenOut)
def login(data: schemas.LoginIn, db: Session = Depends(get_db)):
    user = crud.authenticate(db, data.username, data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos, o cuenta deshabilitada")
    return {"access_token": auth.create_token(user), "token_type": "bearer", "user": user}


@app.post("/api/auth/google", response_model=schemas.TokenOut)
def login_google(data: schemas.GoogleIn, db: Session = Depends(get_db)):
    """Inicio de sesión con Google. Requiere la variable GOOGLE_CLIENT_ID.
    Solo entra quien ya tiene una cuenta creada con ese correo (la crea el administrador)."""
    client_id = os.getenv("GOOGLE_CLIENT_ID")
    if not client_id:
        raise HTTPException(status_code=501, detail="Google Sign-In no está configurado (falta GOOGLE_CLIENT_ID)")
    try:
        url = "https://oauth2.googleapis.com/tokeninfo?id_token=" + urllib.parse.quote(data.credential)
        with urllib.request.urlopen(url, timeout=8) as resp:
            info = json.loads(resp.read().decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=401, detail="No se pudo validar la cuenta de Google")
    if info.get("aud") != client_id or info.get("email_verified") not in (True, "true"):
        raise HTTPException(status_code=401, detail="Credencial de Google no válida")
    user = db.query(models.User).filter(models.User.email == info.get("email")).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=403, detail="Ese correo no tiene una cuenta habilitada en GSLsys")
    return {"access_token": auth.create_token(user), "token_type": "bearer", "user": user}


@app.get("/api/auth/me", response_model=schemas.UserOut)
def me(user: models.User = Depends(auth.get_current_user)):
    return user


# ------------------------------------------------------------------- usuarios
@app.get("/api/users", response_model=List[schemas.UserOut])
def users_list(db: Session = Depends(get_db), _=Depends(auth.require_roles())):
    return crud.list_users(db)


@app.post("/api/users", response_model=schemas.UserOut, status_code=201)
def users_create(data: schemas.UserCreate, db: Session = Depends(get_db), _=Depends(auth.require_roles())):
    return crud.create_user(db, data)


@app.patch("/api/users/{user_id}", response_model=schemas.UserOut)
def users_update(
    user_id: int,
    data: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current: models.User = Depends(auth.require_roles()),
):
    return crud.update_user(db, user_id, data, current)


# ------------------------------------------------------------------ productos
@app.get("/api/products", response_model=schemas.ProductPage)
def products_list(
    search: str = "",
    category: str = "",
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    _=Depends(auth.get_current_user),
):
    return crud.list_products(db, search, category, page, page_size)


@app.get("/api/categories", response_model=List[str])
def categories(db: Session = Depends(get_db), _=Depends(auth.get_current_user)):
    return crud.list_categories(db)


@app.post("/api/products", response_model=schemas.ProductOut, status_code=201)
def products_create(data: schemas.ProductIn, db: Session = Depends(get_db), _=Depends(auth.require_roles("inventory"))):
    return crud.create_product(db, data)


@app.put("/api/products/{product_id}", response_model=schemas.ProductOut)
def products_update(
    product_id: int, data: schemas.ProductIn, db: Session = Depends(get_db), _=Depends(auth.require_roles("inventory"))
):
    return crud.update_product(db, product_id, data)


@app.delete("/api/products/{product_id}", status_code=204)
def products_delete(product_id: int, db: Session = Depends(get_db), _=Depends(auth.require_roles("inventory"))):
    crud.delete_product(db, product_id)
    return Response(status_code=204)


# --------------------------------------------------------------- contabilidad
@app.get("/api/transactions", response_model=schemas.TransactionPage)
def transactions_list(
    month: Optional[str] = None,
    type: Optional[str] = Query(None, pattern="^(venta|compra)$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("accounting")),
):
    return crud.list_transactions(db, month, type, page, page_size)


@app.post("/api/transactions", response_model=schemas.TransactionOut, status_code=201)
def transactions_create(
    data: schemas.TransactionIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_roles("accounting")),
):
    return crud.create_transaction(db, data, user)


@app.get("/api/reports/accounting.pdf")
def accounting_pdf(
    month: Optional[str] = None, db: Session = Depends(get_db), _=Depends(auth.require_roles("accounting"))
):
    _, _, period = crud.month_range(month)
    pdf = pdf_generator.accounting_report(period, crud.month_transactions(db, period), crud.finance_totals(db, period))
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="GSL_ventas_compras_{period}.pdf"'},
    )


# ------------------------------------------------------------------------ RRHH
@app.get("/api/employees", response_model=List[schemas.EmployeeOut])
def employees_list(db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))):
    return crud.list_employees(db)


@app.post("/api/employees", response_model=schemas.EmployeeOut, status_code=201)
def employees_create(data: schemas.EmployeeIn, db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))):
    return crud.create_employee(db, data)


@app.put("/api/employees/{employee_id}", response_model=schemas.EmployeeOut)
def employees_update(
    employee_id: int, data: schemas.EmployeeIn, db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))
):
    return crud.update_employee(db, employee_id, data)


@app.get("/api/overtime", response_model=List[schemas.OvertimeOut])
def overtime_list(
    period: Optional[str] = None,
    employee_id: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("hr")),
):
    return crud.list_overtime(db, period, employee_id)


@app.post("/api/overtime", response_model=schemas.OvertimeOut, status_code=201)
def overtime_create(data: schemas.OvertimeIn, db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))):
    return crud.add_overtime(db, data)


@app.delete("/api/overtime/{overtime_id}", status_code=204)
def overtime_delete(overtime_id: int, db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))):
    crud.delete_overtime(db, overtime_id)
    return Response(status_code=204)


@app.get("/api/payroll", response_model=List[schemas.PayrollRow])
def payroll(period: Optional[str] = None, db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))):
    return crud.compute_payroll(db, period)


@app.get("/api/reports/hr.pdf")
def hr_pdf(period: Optional[str] = None, db: Session = Depends(get_db), _=Depends(auth.require_roles("hr"))):
    _, _, period = crud.month_range(period)
    pdf = pdf_generator.hr_report(
        period,
        crud.list_employees(db),
        crud.compute_payroll(db, period),
        {
            "days": crud.DAYS_PER_MONTH,
            "hours": crud.HOURS_PER_DAY,
            "multiplier": crud.OVERTIME_MULTIPLIER,
            "inss": crud.INSS_RATE,
        },
    )
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="GSL_empleados_nomina_{period}.pdf"'},
    )


# --------------------------------------------------------------------- tablero
@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    return crud.dashboard(db, user)


@app.get("/api/health")
def health():
    return {"status": "ok"}
