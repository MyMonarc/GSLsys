"""Contraseñas con bcrypt y sesiones con JWT."""
import os
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from database import get_db
import models

# En producción define GSL_SECRET_KEY como variable de entorno.
SECRET_KEY = os.getenv("GSL_SECRET_KEY", "gslsys-clave-de-desarrollo-cambiala")
ALGORITHM = "HS256"
TOKEN_MINUTES = 60 * 8

bearer = HTTPBearer(auto_error=False)


def _pw_bytes(password: str) -> bytes:
    return password.encode("utf-8")[:72]  # bcrypt solo usa 72 bytes


def hash_password(password: str) -> str:
    return bcrypt.hashpw(_pw_bytes(password), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(_pw_bytes(password), hashed.encode("utf-8"))
    except ValueError:
        return False


def create_token(user: models.User) -> str:
    payload = {
        "sub": str(user.id),
        "exp": datetime.now(timezone.utc) + timedelta(minutes=TOKEN_MINUTES),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
) -> models.User:
    unauthorized = HTTPException(status_code=401, detail="Sesión no válida o vencida")
    if creds is None:
        raise unauthorized
    try:
        payload = jwt.decode(creds.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise unauthorized
    user = db.get(models.User, user_id)
    if user is None or not user.is_active:
        raise unauthorized
    return user


def require_roles(*roles: str):
    """El administrador siempre pasa; los demás necesitan alguno de los roles indicados."""

    def checker(user: models.User = Depends(get_current_user)) -> models.User:
        if "admin" in user.roles or any(r in user.roles for r in roles):
            return user
        raise HTTPException(status_code=403, detail="No tienes permiso para esta acción")

    return checker
