"""Conexión SQLite + tipo de fecha con zona horaria de Nicaragua (UTC-6)."""
import os
from datetime import datetime, timedelta, timezone

from sqlalchemy import DateTime, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import TypeDecorator

# Nicaragua no usa horario de verano: siempre UTC-6.
NI_TZ = timezone(timedelta(hours=-6), name="UTC-6")


def now_ni() -> datetime:
    """Fecha y hora actual en Nicaragua (con tzinfo UTC-6)."""
    return datetime.now(NI_TZ)


class NITime(TypeDecorator):
    """Guarda datetimes como hora local de Nicaragua (UTC-6) y los devuelve con tzinfo."""

    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=NI_TZ)
        return value.astimezone(NI_TZ).replace(tzinfo=None)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return value.replace(tzinfo=NI_TZ)


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'gslsys.db')}"

# El archivo gslsys.db se crea solo la primera vez que arranca el servidor.
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
