"""Lógica de negocio: usuarios, inventario, finanzas, nómina y datos iniciales."""
import calendar
import math
import random
from datetime import date, datetime, timedelta
from typing import Optional

from sqlalchemy import func, or_
from sqlalchemy.orm import Session

import auth
import models
import schemas
from database import NI_TZ, now_ni


class CrudError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


# ---------------------------------------------------------------- utilidades
def paginate(query, page: int, page_size: int) -> dict:
    total = query.count()
    pages = max(1, math.ceil(total / page_size))
    page = min(max(page, 1), pages)
    items = query.offset((page - 1) * page_size).limit(page_size).all()
    return {"items": items, "total": total, "page": page, "pages": pages}


def month_range(month: Optional[str]):
    """Devuelve (inicio, fin, 'YYYY-MM') del mes en hora de Nicaragua."""
    if not month:
        month = now_ni().strftime("%Y-%m")
    try:
        year, mon = (int(x) for x in month.split("-"))
        start = datetime(year, mon, 1, tzinfo=NI_TZ)
    except ValueError:
        raise CrudError("El período debe tener el formato AAAA-MM")
    end = datetime(year + (mon == 12), 1 if mon == 12 else mon + 1, 1, tzinfo=NI_TZ)
    return start, end, month


def clean_roles(roles):
    invalid = [r for r in roles if r not in schemas.ROLES]
    if invalid:
        raise CrudError(f"Rol no válido: {', '.join(invalid)}")
    return roles


# ------------------------------------------------------------------ usuarios
def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(func.lower(models.User.username) == username.lower()).first()


def authenticate(db: Session, username: str, password: str):
    user = get_user_by_username(db, username.strip())
    if user and user.is_active and auth.verify_password(password, user.hashed_password):
        return user
    return None


def list_users(db: Session):
    return db.query(models.User).order_by(models.User.id).all()


def create_user(db: Session, data: schemas.UserCreate) -> models.User:
    if get_user_by_username(db, data.username):
        raise CrudError("Ese nombre de usuario ya existe")
    email = (data.email or "").strip() or None
    if email and db.query(models.User).filter(models.User.email == email).first():
        raise CrudError("Ese correo ya está registrado")
    user = models.User(
        username=data.username.strip(),
        full_name=data.full_name.strip(),
        email=email,
        hashed_password=auth.hash_password(data.password),
        is_active=True,
    )
    user.roles = clean_roles(data.roles)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def update_user(db: Session, user_id: int, data: schemas.UserUpdate, current: models.User) -> models.User:
    user = db.get(models.User, user_id)
    if not user:
        raise CrudError("Usuario no encontrado", 404)
    if user.id == current.id:
        if data.is_active is False:
            raise CrudError("No puedes deshabilitar tu propia cuenta")
        if data.roles is not None and "admin" not in data.roles:
            raise CrudError("No puedes quitarte el rol de administrador")
    if data.full_name is not None:
        user.full_name = data.full_name.strip()
    if data.email is not None:
        email = data.email.strip() or None
        if email:
            other = db.query(models.User).filter(models.User.email == email, models.User.id != user.id).first()
            if other:
                raise CrudError("Ese correo ya está registrado")
        user.email = email
    if data.password:
        user.hashed_password = auth.hash_password(data.password)
    if data.roles is not None:
        user.roles = clean_roles(data.roles)
    if data.is_active is not None:
        user.is_active = data.is_active
    db.commit()
    db.refresh(user)
    return user


# ----------------------------------------------------------------- productos
def list_products(db: Session, search: str, category: str, page: int, page_size: int):
    q = db.query(models.Product)
    if search:
        like = f"%{search.strip()}%"
        q = q.filter(
            or_(
                models.Product.name.ilike(like),
                models.Product.sku.ilike(like),
                models.Product.category.ilike(like),
                models.Product.description.ilike(like),
            )
        )
    if category:
        q = q.filter(models.Product.category == category)
    return paginate(q.order_by(models.Product.created_at.desc(), models.Product.id.desc()), page, page_size)


def list_categories(db: Session):
    rows = db.query(models.Product.category).distinct().order_by(models.Product.category).all()
    return [r[0] for r in rows]


def create_product(db: Session, data: schemas.ProductIn) -> models.Product:
    if db.query(models.Product).filter(models.Product.sku == data.sku.strip()).first():
        raise CrudError("Ya existe un producto con ese SKU")
    product = models.Product(**data.model_dump(), created_at=now_ni())
    product.sku = product.sku.strip()
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


def update_product(db: Session, product_id: int, data: schemas.ProductIn) -> models.Product:
    product = db.get(models.Product, product_id)
    if not product:
        raise CrudError("Producto no encontrado", 404)
    dup = db.query(models.Product).filter(models.Product.sku == data.sku.strip(), models.Product.id != product_id).first()
    if dup:
        raise CrudError("Ya existe un producto con ese SKU")
    for key, value in data.model_dump().items():
        setattr(product, key, value)  # created_at no se toca: es la fecha de ingreso
    db.commit()
    db.refresh(product)
    return product


def delete_product(db: Session, product_id: int):
    product = db.get(models.Product, product_id)
    if not product:
        raise CrudError("Producto no encontrado", 404)
    db.query(models.Transaction).filter(models.Transaction.product_id == product_id).update({"product_id": None})
    db.delete(product)
    db.commit()


# ------------------------------------------------------------- transacciones
def create_transaction(db: Session, data: schemas.TransactionIn, user: models.User) -> models.Transaction:
    product = None
    if data.product_id:
        product = db.get(models.Product, data.product_id)
        if not product:
            raise CrudError("Producto no encontrado", 404)
    amount = data.amount
    if amount is None:
        if not product:
            raise CrudError("Indica el monto o selecciona un producto")
        unit = product.price if data.type == "venta" else product.cost
        amount = round(unit * data.quantity, 2)
    if product:
        if data.type == "venta":
            if product.stock < data.quantity:
                raise CrudError(f"Stock insuficiente: quedan {product.stock} unidades de {product.name}")
            product.stock -= data.quantity
        else:
            product.stock += data.quantity
    tx = models.Transaction(
        type=data.type,
        description=data.description.strip(),
        product_id=product.id if product else None,
        quantity=data.quantity,
        amount=amount,
        user_id=user.id,
        created_at=now_ni(),
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return tx


def _tx_query(db: Session, month: Optional[str], tx_type: Optional[str]):
    start, end, _ = month_range(month)
    q = db.query(models.Transaction).filter(
        models.Transaction.created_at >= start, models.Transaction.created_at < end
    )
    if tx_type:
        q = q.filter(models.Transaction.type == tx_type)
    return q


def finance_totals(db: Session, month: Optional[str]) -> dict:
    start, end, _ = month_range(month)
    out = {}
    for kind in ("venta", "compra"):
        total = (
            db.query(func.coalesce(func.sum(models.Transaction.amount), 0.0))
            .filter(
                models.Transaction.type == kind,
                models.Transaction.created_at >= start,
                models.Transaction.created_at < end,
            )
            .scalar()
        )
        out[kind] = round(float(total), 2)
    return {"total_ventas": out["venta"], "total_compras": out["compra"]}


def list_transactions(db: Session, month: Optional[str], tx_type: Optional[str], page: int, page_size: int):
    q = _tx_query(db, month, tx_type).order_by(models.Transaction.created_at.desc(), models.Transaction.id.desc())
    result = paginate(q, page, page_size)
    result.update(finance_totals(db, month))
    return result


def month_transactions(db: Session, month: Optional[str]):
    return _tx_query(db, month, None).order_by(models.Transaction.created_at, models.Transaction.id).all()


# ------------------------------------------------------------------- RR. HH.
# Parámetros de nómina (verifícalos con la normativa vigente antes de usarlos en serio).
HOURS_PER_DAY = 8          # jornada ordinaria diurna
DAYS_PER_MONTH = 30        # divisor para el salario diario
OVERTIME_MULTIPLIER = 2.0  # Código del Trabajo: hora extra pagada con 100% de recargo (doble)
INSS_RATE = 0.07           # aporte laboral al INSS
# Tabla anual del IR sobre salarios: (límite inferior, impuesto base, tasa sobre el excedente)
IR_BRACKETS = [
    (0, 0.0, 0.0),
    (100_000, 0.0, 0.15),
    (200_000, 15_000.0, 0.20),
    (350_000, 45_000.0, 0.25),
    (500_000, 82_500.0, 0.30),
]


def annual_ir(annual_income: float) -> float:
    lower, base, rate = IR_BRACKETS[0]
    for bracket in IR_BRACKETS:
        if annual_income > bracket[0]:
            lower, base, rate = bracket
    if annual_income <= 100_000:
        return 0.0
    return base + (annual_income - lower) * rate


def list_employees(db: Session):
    return db.query(models.Employee).order_by(models.Employee.full_name).all()


def create_employee(db: Session, data: schemas.EmployeeIn) -> models.Employee:
    emp = models.Employee(**data.model_dump())
    db.add(emp)
    db.commit()
    db.refresh(emp)
    return emp


def update_employee(db: Session, employee_id: int, data: schemas.EmployeeIn) -> models.Employee:
    emp = db.get(models.Employee, employee_id)
    if not emp:
        raise CrudError("Empleado no encontrado", 404)
    for key, value in data.model_dump().items():
        setattr(emp, key, value)
    db.commit()
    db.refresh(emp)
    return emp


def add_overtime(db: Session, data: schemas.OvertimeIn) -> models.Overtime:
    if not db.get(models.Employee, data.employee_id):
        raise CrudError("Empleado no encontrado", 404)
    record = models.Overtime(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def list_overtime(db: Session, period: Optional[str], employee_id: Optional[int] = None):
    start, end, _ = month_range(period)
    q = db.query(models.Overtime).filter(
        models.Overtime.work_date >= start.date(), models.Overtime.work_date < end.date()
    )
    if employee_id:
        q = q.filter(models.Overtime.employee_id == employee_id)
    return q.order_by(models.Overtime.work_date.desc(), models.Overtime.id.desc()).all()


def delete_overtime(db: Session, overtime_id: int):
    record = db.get(models.Overtime, overtime_id)
    if not record:
        raise CrudError("Registro no encontrado", 404)
    db.delete(record)
    db.commit()


def compute_payroll(db: Session, period: Optional[str]):
    start, end, _ = month_range(period)
    last_day = end.date() - timedelta(days=1)
    hours_by_emp = dict(
        db.query(models.Overtime.employee_id, func.sum(models.Overtime.hours))
        .filter(models.Overtime.work_date >= start.date(), models.Overtime.work_date <= last_day)
        .group_by(models.Overtime.employee_id)
        .all()
    )
    employees = (
        db.query(models.Employee)
        .filter(models.Employee.is_active.is_(True), models.Employee.hire_date <= last_day)
        .order_by(models.Employee.full_name)
        .all()
    )
    rows = []
    for emp in employees:
        hourly = emp.base_salary / DAYS_PER_MONTH / HOURS_PER_DAY
        hours = float(hours_by_emp.get(emp.id, 0) or 0)
        overtime_pay = hours * hourly * OVERTIME_MULTIPLIER
        gross = emp.base_salary + overtime_pay
        inss = gross * INSS_RATE
        ir = annual_ir((gross - inss) * 12) / 12
        rows.append(
            {
                "employee_id": emp.id,
                "full_name": emp.full_name,
                "position": emp.position,
                "base_salary": round(emp.base_salary, 2),
                "hourly_rate": round(hourly, 2),
                "overtime_hours": round(hours, 2),
                "overtime_pay": round(overtime_pay, 2),
                "gross": round(gross, 2),
                "inss": round(inss, 2),
                "ir": round(ir, 2),
                "net": round(gross - inss - ir, 2),
            }
        )
    return rows


# ------------------------------------------------------------------ tablero
LOW_STOCK = 10


def dashboard(db: Session, user: models.User) -> dict:
    is_admin = "admin" in user.roles
    data = {
        "products": db.query(models.Product).count(),
        "low_stock": db.query(models.Product).filter(models.Product.stock < LOW_STOCK).count(),
        "low_stock_items": [
            {"id": p.id, "name": p.name, "stock": p.stock, "emoji": p.emoji}
            for p in db.query(models.Product).filter(models.Product.stock < LOW_STOCK).order_by(models.Product.stock).limit(5)
        ],
        "finance": None,
        "employees": None,
        "users": None,
    }
    if is_admin or "accounting" in user.roles:
        data["finance"] = finance_totals(db, None)
    if is_admin or "hr" in user.roles:
        data["employees"] = db.query(models.Employee).filter(models.Employee.is_active.is_(True)).count()
    if is_admin:
        data["users"] = db.query(models.User).count()
    return data


# -------------------------------------------------------------- datos iniciales
SEED_PRODUCTS = [
    ("DEP-001", "Balón de fútbol profesional No. 5", "Fútbol", "⚽", "Balón termosellado para cancha y grama sintética.", 950, 560, 40),
    ("DEP-002", "Camiseta de entrenamiento Dry-Fit", "Ropa deportiva", "👕", "Tela transpirable de secado rápido.", 620, 340, 65),
    ("DEP-003", "Guantes de portero con grip", "Fútbol", "🧤", "Palma de látex con ajuste en muñeca.", 780, 430, 18),
    ("DEP-004", "Botella deportiva térmica 750 ml", "Accesorios", "🥤", "Acero inoxidable, mantiene frío por 12 horas.", 540, 290, 52),
    ("DEP-005", "Mochila deportiva 35 L", "Accesorios", "🎒", "Compartimento para calzado y bolsillo impermeable.", 1150, 640, 24),
    ("DEP-006", "Cuerda para saltar con rodamientos", "Fitness", "🪢", "Mangos antideslizantes, largo ajustable.", 290, 140, 70),
    ("DEP-007", "Mancuernas ajustables 2 x 10 kg", "Fitness", "🏋️", "Juego con discos intercambiables.", 2450, 1580, 9),
    ("DEP-008", "Zapatillas de running Pace X", "Calzado", "👟", "Amortiguación ligera para asfalto.", 2890, 1760, 14),
    ("DEP-009", "Colchoneta de yoga 6 mm", "Fitness", "🧘", "Superficie antideslizante con correa.", 680, 360, 33),
    ("DEP-010", "Gorra deportiva ajustable", "Ropa deportiva", "🧢", "Visera curva con banda absorbente.", 360, 170, 48),
    ("STR-001", "Micrófono USB para transmisión", "Streaming", "🎙️", "Cardioide, ideal para comentarios en vivo.", 2150, 1320, 12),
    ("STR-002", "Cámara web Full HD 1080p", "Streaming", "📷", "Enfoque automático y micrófono integrado.", 1890, 1130, 16),
    ("STR-003", "Aro de luz LED 12 pulgadas con trípode", "Streaming", "💡", "Tres tonos de luz y control de brillo.", 1320, 760, 7),
    ("STR-004", "Tarjeta de captura HDMI 4K", "Streaming", "🎬", "Captura de consolas y cámaras para transmitir partidos.", 3250, 2100, 6),
    ("STR-005", "Audífonos cerrados para monitoreo", "Streaming", "🎧", "Cable desmontable y almohadillas de espuma.", 1480, 880, 21),
]

SEED_EMPLOYEES = [
    ("Carlos Mejía Ruiz", "Gerente de tienda", date(2021, 3, 15), 18000),
    ("Lucía Pérez Obando", "Vendedora", date(2022, 7, 4), 11500),
    ("José Ramón Téllez", "Encargado de bodega", date(2023, 1, 23), 10200),
    ("María Fernanda Alemán", "Productora de contenido", date(2023, 9, 11), 13800),
    ("Daniel Sandoval Cruz", "Técnico de transmisión", date(2024, 5, 6), 15500),
]


def seed_data(db: Session):
    """Pobla la base la primera vez que arranca el servidor (si no hay usuarios)."""
    if db.query(models.User).count() > 0:
        return
    rng = random.Random(2026)
    now = now_ni()

    users = {}
    for username, full_name, email, password, roles in [
        ("admin", "Administrador GSL", "admin@gslsys.com", "Admin123!", ["admin"]),
        ("rrhh", "Ana Gómez (Recursos Humanos)", "rrhh@gslsys.com", "Rrhh123!", ["hr"]),
        ("contabilidad", "Pedro Silva (Contabilidad)", "contabilidad@gslsys.com", "Conta123!", ["accounting"]),
        ("inventario", "Sofía Rivas (Inventario)", "inventario@gslsys.com", "Inventario123!", ["inventory"]),
    ]:
        u = models.User(
            username=username,
            full_name=full_name,
            email=email,
            hashed_password=auth.hash_password(password),
            is_active=True,
            created_at=now,
        )
        u.roles = roles
        db.add(u)
        users[username] = u
    db.flush()

    products = []
    for i, (sku, name, cat, emoji, desc, price, cost, stock) in enumerate(SEED_PRODUCTS):
        entered = now - timedelta(days=rng.randint(0, 70), hours=rng.randint(0, 9), minutes=rng.randint(0, 59), seconds=rng.randint(0, 59))
        p = models.Product(
            sku=sku, name=name, category=cat, emoji=emoji, description=desc,
            price=price, cost=cost, stock=stock, created_at=entered,
        )
        db.add(p)
        products.append(p)
    db.flush()

    accountant = users["contabilidad"]
    for n in range(26):
        days_ago = rng.randint(0, 38)
        when = now - timedelta(days=days_ago, hours=rng.randint(0, 8), minutes=rng.randint(0, 59), seconds=rng.randint(0, 59))
        product = rng.choice(products)
        qty = rng.randint(1, 5)
        if n % 3 == 0:
            tx_type, amount = "compra", round(product.cost * qty * 3, 2)
            qty *= 3
            desc = f"Compra a proveedor: {product.name}"
        else:
            tx_type, amount = "venta", round(product.price * qty, 2)
            desc = f"Venta: {product.name}"
        db.add(models.Transaction(
            type=tx_type, description=desc, product_id=product.id, quantity=qty,
            amount=amount, user_id=accountant.id, created_at=when,
        ))

    employees = []
    for name, position, hired, salary in SEED_EMPLOYEES:
        emp = models.Employee(full_name=name, position=position, hire_date=hired, base_salary=salary, is_active=True)
        db.add(emp)
        employees.append(emp)
    db.flush()

    today = now.date()
    last_month_day = today.replace(day=1) - timedelta(days=1)
    for emp, hours, day in [
        (employees[1], 3, today.replace(day=min(today.day, 5))),
        (employees[2], 4.5, today.replace(day=min(today.day, 8))),
        (employees[4], 6, today.replace(day=min(today.day, 3))),
        (employees[1], 2, last_month_day.replace(day=10)),
        (employees[3], 5, last_month_day.replace(day=18)),
        (employees[4], 8, last_month_day.replace(day=22)),
    ]:
        db.add(models.Overtime(employee_id=emp.id, work_date=day, hours=hours, note="Horario especial / transmisión"))
    db.commit()
