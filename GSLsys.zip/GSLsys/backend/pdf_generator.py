"""Reportes PDF con membrete de Granada SportLine (ReportLab)."""
from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from database import now_ni

NAVY = colors.HexColor("#0A2240")
NAVY_2 = colors.HexColor("#002D62")
RED = colors.HexColor("#E31837")
SILVER = colors.HexColor("#C0C0C0")
MIST = colors.HexColor("#E5E7EB")
WHITE = colors.white

MONTHS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
          "agosto", "septiembre", "octubre", "noviembre", "diciembre"]

H1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=18, leading=22, textColor=NAVY, spaceAfter=2)
SUB = ParagraphStyle("sub", fontName="Helvetica", fontSize=10, leading=13, textColor=colors.HexColor("#4B5563"))
H2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=12, leading=15, textColor=NAVY, spaceBefore=14, spaceAfter=6)
CELL = ParagraphStyle("cell", fontName="Helvetica", fontSize=8.5, leading=10.5, textColor=colors.HexColor("#111827"))
NOTE = ParagraphStyle("note", fontName="Helvetica", fontSize=8, leading=10.5, textColor=colors.HexColor("#4B5563"))
EMPTY = ParagraphStyle("empty", parent=CELL, fontSize=9, textColor=colors.HexColor("#6B7280"))


def money(value) -> str:
    return f"C$ {float(value):,.2f}"


def period_label(period: str) -> str:
    year, mon = period.split("-")
    return f"{MONTHS[int(mon) - 1].capitalize()} {year}"


def _stamp() -> str:
    return now_ni().strftime("%d/%m/%Y %H:%M") + " (UTC-6)"


def _page_decorator(report_title: str):
    def draw(canvas, doc):
        w, h = canvas._pagesize
        canvas.saveState()
        # Membrete: franja azul marino con filete rojo
        canvas.setFillColor(NAVY)
        canvas.rect(0, h - 30 * mm, w, 30 * mm, stroke=0, fill=1)
        canvas.setFillColor(RED)
        canvas.rect(0, h - 33 * mm, w, 3 * mm, stroke=0, fill=1)
        # Marca
        canvas.roundRect(15 * mm, h - 24 * mm, 17 * mm, 14 * mm, 2 * mm, stroke=0, fill=1)
        canvas.setFillColor(WHITE)
        canvas.setFont("Helvetica-Bold", 15)
        canvas.drawCentredString(23.5 * mm, h - 19 * mm, "GSL")
        canvas.setFont("Helvetica-Bold", 16)
        canvas.drawString(37 * mm, h - 16.5 * mm, "GRANADA SPORTLINE")
        canvas.setFont("Helvetica", 9)
        canvas.setFillColor(SILVER)
        canvas.drawString(37 * mm, h - 22.5 * mm, "Accesorios deportivos y streaming  |  GSLsys.com")
        canvas.setFillColor(WHITE)
        canvas.setFont("Helvetica-Bold", 10)
        canvas.drawRightString(w - 15 * mm, h - 16.5 * mm, report_title)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(SILVER)
        canvas.drawRightString(w - 15 * mm, h - 22.5 * mm, "Generado: " + _stamp())
        # Pie
        canvas.setStrokeColor(SILVER)
        canvas.setLineWidth(0.6)
        canvas.line(15 * mm, 14 * mm, w - 15 * mm, 14 * mm)
        canvas.setFillColor(colors.HexColor("#6B7280"))
        canvas.setFont("Helvetica", 8)
        canvas.drawString(15 * mm, 9 * mm, "Granada SportLine - Documento interno generado por GSLsys.com")
        canvas.drawRightString(w - 15 * mm, 9 * mm, f"Página {doc.page}")
        canvas.restoreState()

    return draw


def _build(story, report_title, pagesize):
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=pagesize, leftMargin=15 * mm, rightMargin=15 * mm,
        topMargin=42 * mm, bottomMargin=22 * mm,
        title=report_title, author="Granada SportLine - GSLsys.com",
    )
    deco = _page_decorator(report_title)
    doc.build(story, onFirstPage=deco, onLaterPages=deco)
    return buf.getvalue()


def _table(data, col_widths, right_cols=(), total_row=False):
    t = Table(data, colWidths=col_widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 8.5),
        ("FONTSIZE", (0, 1), (-1, -1), 8.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, MIST]),
        ("GRID", (0, 0), (-1, -1), 0.4, SILVER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for c in right_cols:
        style.append(("ALIGN", (c, 0), (c, -1), "RIGHT"))
    if total_row:
        style += [
            ("BACKGROUND", (0, -1), (-1, -1), NAVY_2),
            ("TEXTCOLOR", (0, -1), (-1, -1), WHITE),
            ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
            ("LINEABOVE", (0, -1), (-1, -1), 1.5, RED),
        ]
    t.setStyle(TableStyle(style))
    return t


def _summary_boxes(items, total_width):
    """Tarjetas de resumen: [(etiqueta, valor, color_valor)]"""
    n = len(items)
    label = ParagraphStyle("lb", fontName="Helvetica", fontSize=8.5, textColor=colors.HexColor("#4B5563"))
    cells = []
    for text, value, color in items:
        val = ParagraphStyle("vl", fontName="Helvetica-Bold", fontSize=14, leading=17, textColor=color)
        cells.append([Paragraph(text, label), Paragraph(value, val)])
    row = [c for c in cells]
    t = Table([row], colWidths=[total_width / n] * n)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), MIST),
        ("BOX", (0, 0), (-1, -1), 0.6, SILVER),
        ("INNERGRID", (0, 0), (-1, -1), 0.6, WHITE),
        ("LINEBEFORE", (0, 0), (0, -1), 3, RED),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
    ]))
    return t


def _fmt_dt(dt) -> str:
    return dt.strftime("%d/%m/%Y %H:%M:%S")


# ---------------------------------------------------------------- Contabilidad
def accounting_report(period: str, transactions, totals: dict) -> bytes:
    """Reporte Mensual de Ventas y Compras."""
    title = "Reporte mensual de ventas y compras"
    page_w = A4[0] - 30 * mm
    ventas = [t for t in transactions if t.type == "venta"]
    compras = [t for t in transactions if t.type == "compra"]
    balance = totals["total_ventas"] - totals["total_compras"]

    story = [
        Paragraph(title, H1),
        Paragraph(f"Período: {period_label(period)}. Fechas y horas en horario de Nicaragua (UTC-6).", SUB),
        Spacer(1, 10),
        _summary_boxes([
            ("Total de ventas", money(totals["total_ventas"]), NAVY),
            ("Total de compras", money(totals["total_compras"]), NAVY),
            ("Balance (ventas - compras)", money(balance), RED if balance < 0 else NAVY),
        ], page_w),
    ]

    def section(name, rows, total):
        story.append(Paragraph(f"{name} ({len(rows)})", H2))
        if not rows:
            story.append(Paragraph("Sin registros en este período.", EMPTY))
            return
        data = [["Fecha y hora", "Descripción", "Cant.", "Registrado por", "Monto"]]
        for t in rows:
            data.append([
                _fmt_dt(t.created_at),
                Paragraph(t.description, CELL),
                str(t.quantity),
                Paragraph(t.user_name, CELL),
                money(t.amount),
            ])
        data.append(["", "Total " + name.lower(), "", "", money(total)])
        story.append(_table(data, [33 * mm, 62 * mm, 14 * mm, 38 * mm, 33 * mm], right_cols=(2, 4), total_row=True))

    section("Ventas", ventas, totals["total_ventas"])
    section("Compras", compras, totals["total_compras"])
    return _build(story, title, A4)


# ------------------------------------------------------------------------ RR.HH
def hr_report(period: str, employees, payroll: list, params: dict) -> bytes:
    """Reporte de Empleados y Nómina (horizontal)."""
    title = "Reporte de empleados y nómina"
    size = landscape(A4)
    page_w = size[0] - 30 * mm

    story = [
        Paragraph(title, H1),
        Paragraph(f"Período de nómina: {period_label(period)}. Montos en córdobas (C$).", SUB),
        Spacer(1, 10),
    ]

    total_gross = sum(r["gross"] for r in payroll)
    total_net = sum(r["net"] for r in payroll)
    story.append(_summary_boxes([
        ("Empleados activos en nómina", str(len(payroll)), NAVY),
        ("Total salario bruto", money(total_gross), NAVY),
        ("Total neto a pagar", money(total_net), RED),
    ], page_w))

    story.append(Paragraph(f"Personal ({len(employees)})", H2))
    data = [["Empleado", "Cargo", "Fecha de ingreso", "Salario base mensual", "Estado"]]
    for e in employees:
        data.append([
            Paragraph(e.full_name, CELL), Paragraph(e.position, CELL),
            e.hire_date.strftime("%d/%m/%Y"), money(e.base_salary),
            "Activo" if e.is_active else "Inactivo",
        ])
    story.append(_table(data, [70 * mm, 65 * mm, 38 * mm, 50 * mm, 30 * mm], right_cols=(3,)))

    story.append(Paragraph(f"Nómina de {period_label(period)}", H2))
    if not payroll:
        story.append(Paragraph("No hay empleados activos para este período.", EMPTY))
    else:
        data = [["Empleado", "Salario base", "H. extra", "Pago H. extra", "Bruto", "INSS", "IR", "Neto"]]
        for r in payroll:
            data.append([
                Paragraph(r["full_name"], CELL), money(r["base_salary"]), f'{r["overtime_hours"]:g}',
                money(r["overtime_pay"]), money(r["gross"]), money(r["inss"]), money(r["ir"]), money(r["net"]),
            ])
        data.append([
            "Totales", money(sum(r["base_salary"] for r in payroll)),
            f'{sum(r["overtime_hours"] for r in payroll):g}',
            money(sum(r["overtime_pay"] for r in payroll)), money(total_gross),
            money(sum(r["inss"] for r in payroll)), money(sum(r["ir"] for r in payroll)), money(total_net),
        ])
        story.append(_table(data, [58 * mm, 32 * mm, 18 * mm, 32 * mm, 32 * mm, 28 * mm, 28 * mm, 32 * mm],
                            right_cols=(1, 2, 3, 4, 5, 6, 7), total_row=True))

    story.append(Spacer(1, 10))
    story.append(Paragraph(
        f"Criterios de cálculo: valor de la hora = salario base / {params['days']} días / {params['hours']} horas. "
        f"Las horas extras se pagan al doble (x{params['multiplier']:g}). INSS laboral {params['inss'] * 100:g}% sobre el bruto. "
        "El IR se calcula sobre el ingreso anualizado (bruto menos INSS) con la tabla progresiva de salarios. "
        "Estos parámetros son una referencia básica: confírmalos con la normativa laboral y tributaria vigente.",
        NOTE,
    ))
    return _build(story, title, size)
