from datetime import date, datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

ROLES = ["admin", "inventory", "accounting", "hr"]


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- Autenticación y usuarios ----------
class LoginIn(BaseModel):
    username: str
    password: str


class GoogleIn(BaseModel):
    credential: str


class UserOut(ORM):
    id: int
    username: str
    email: Optional[str] = None
    full_name: str
    is_active: bool
    roles: List[str]
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    full_name: str = Field(min_length=2, max_length=120)
    email: Optional[str] = None
    password: str = Field(min_length=6, max_length=72)
    roles: List[str] = []


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    email: Optional[str] = None
    password: Optional[str] = Field(default=None, min_length=6, max_length=72)
    roles: Optional[List[str]] = None
    is_active: Optional[bool] = None


# ---------- Productos ----------
class ProductIn(BaseModel):
    sku: str = Field(min_length=2, max_length=30)
    name: str = Field(min_length=2, max_length=150)
    category: str = Field(min_length=2, max_length=60)
    description: str = ""
    emoji: str = "🏷️"
    price: float = Field(ge=0)
    cost: float = Field(ge=0)
    stock: int = Field(ge=0)


class ProductOut(ORM):
    id: int
    sku: str
    name: str
    category: str
    description: Optional[str] = ""
    emoji: Optional[str] = "🏷️"
    price: float
    cost: float
    stock: int
    created_at: datetime


class ProductPage(BaseModel):
    items: List[ProductOut]
    total: int
    page: int
    pages: int


# ---------- Transacciones ----------
class TransactionIn(BaseModel):
    type: Literal["venta", "compra"]
    description: str = Field(min_length=2, max_length=250)
    product_id: Optional[int] = None
    quantity: int = Field(default=1, ge=1)
    amount: Optional[float] = Field(default=None, gt=0)


class TransactionOut(ORM):
    id: int
    type: str
    description: str
    product_id: Optional[int] = None
    product_name: Optional[str] = None
    quantity: int
    amount: float
    user_id: int
    user_name: str
    created_at: datetime


class TransactionPage(BaseModel):
    items: List[TransactionOut]
    total: int
    page: int
    pages: int
    total_ventas: float
    total_compras: float


# ---------- Recursos Humanos ----------
class EmployeeIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    position: str = Field(min_length=2, max_length=100)
    hire_date: date
    base_salary: float = Field(gt=0)
    is_active: bool = True


class EmployeeOut(ORM):
    id: int
    full_name: str
    position: str
    hire_date: date
    base_salary: float
    is_active: bool


class OvertimeIn(BaseModel):
    employee_id: int
    work_date: date
    hours: float = Field(gt=0, le=24)
    note: str = ""


class OvertimeOut(ORM):
    id: int
    employee_id: int
    work_date: date
    hours: float
    note: Optional[str] = ""


class PayrollRow(BaseModel):
    employee_id: int
    full_name: str
    position: str
    base_salary: float
    hourly_rate: float
    overtime_hours: float
    overtime_pay: float
    gross: float
    inss: float
    ir: float
    net: float
